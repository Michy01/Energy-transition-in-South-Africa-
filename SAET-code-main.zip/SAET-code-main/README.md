# SAET-code
SAET : South Africa Energy Transition

This  is a coding part of the project titles "use Social Network Analysis and Topic Modeling to understand actor's role in the Energy Transition in South Africa" 

The work is divided in two parts
The first part is to build actor's hyperlink network.
The second pard is do Topic modeling on their discussions

To achieve we follow these steps

1- Using  Scrapy to scrap actor website to collect other site url
2- Build Network and compute metrics
3- Scraping web with selenium to get actor discussion's
4- Apply LDA to labelling discussion
